"""Single monochrome raster source for preview, GDI and TSPL bitmap output."""

from pathlib import Path
from functools import lru_cache
import os
from barcode import Code128
from PIL import Image, ImageDraw, ImageFont, ImageChops, features
from fontTools.ttLib import TTFont
from .layout import rows


@lru_cache
def font_path():
    candidates = [
        os.environ.get("LABEL_FONT", ""),
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for p in candidates:
        if p and Path(p).is_file():
            return p
    raise ValueError("Install a Unicode TrueType font and set LABEL_FONT to its path")


@lru_cache
def glyphs():
    with TTFont(font_path()) as f:
        return set(f.getBestCmap())


def text_fit(draw, text, box, min_size=12, max_size=20, lines=1, bold=False):
    if any(ord(c) not in glyphs() for c in text):
        raise ValueError(f"Font lacks glyphs for: {text}")
    if any("\u0600" <= c <= "\u06ff" for c in text) and not features.check_feature(
        "raqm"
    ):
        raise ValueError(
            "Arabic shaping requires Pillow with libraqm; choose a supported symbol"
        )
    x, y, w, h = box
    for size in range(max_size, min_size - 1, -1):
        path = font_path()
        bold_path = path.replace("DejaVuSans.ttf", "DejaVuSans-Bold.ttf").replace(
            "arial.ttf", "arialbd.ttf"
        )
        font = ImageFont.truetype(
            bold_path if bold and Path(bold_path).exists() else path, size
        )
        words = text.split(" ")
        parts = [""]
        for word in words:
            trial = (parts[-1] + " " + word).strip()
            if draw.textlength(trial, font=font) > w and parts[-1]:
                parts.append(word)
            else:
                parts[-1] = trial
        line_h = size + 3
        if (
            len(parts) <= lines
            and len(parts) * line_h <= h
            and all(draw.textlength(t, font=font) <= w for t in parts)
        ):
            for i, t in enumerate(parts):
                draw.text(
                    (x + w / 2, y + i * line_h), t, fill=0, font=font, anchor="mt"
                )
            return
    raise ValueError(f"Text cannot fit without truncation: {text}")


def label(product, g):
    w, h = g.dots(g.width), g.dots(g.height)
    s = g.dots(g.safe)
    im = Image.new("1", (w, h), 1)
    d = ImageDraw.Draw(im)
    text_fit(d, product.name, (s, s, w - 2 * s, 48), 12, 20, 2, True)
    bits = Code128(product.barcode).build()[0]
    # Narrow bars require an explicit profile choice and fresh physical scans.
    # Draw whole printer dots; never resample bars or crop the ten-module quiet zones.
    module = g.barcode_module
    bw = (len(bits) + 20) * module
    if bw > w - 2 * s:
        raise ValueError(
            f"Barcode {product.barcode} needs {bw} dots including quiet zones; only {w - 2 * s} available. "
            + (
                "For this roll, select Narrow bars in Printer settings and print/scan the new calibration sample."
                if module == 2
                else "Even narrow bars do not fit; use wider labels or a suitable higher-resolution printer."
            )
        )
    x = (w - bw) // 2 + 10 * module
    y = s + 52
    bh = g.dots(6)
    if y + bh + 51 > h - s:
        raise ValueError("Label too short for readable content")
    for i, b in enumerate(bits):
        if b == "1":
            d.rectangle(
                (x + i * module, y, x + (i + 1) * module - 1, y + bh - 1), fill=0
            )
    text_fit(d, product.barcode, (s, y + bh + 3, w - 2 * s, 22), 12, 16)
    text_fit(
        d,
        f"{product.symbol} {product.price:,.{max(0, -product.price.as_tuple().exponent)}f}",
        (s, h - s - 25, w - 2 * s, 25),
        12,
        20,
        1,
        True,
    )
    bounds = ImageChops.invert(im.convert("L")).getbbox()
    if bounds and (
        bounds[0] < s or bounds[1] < s or bounds[2] > w - s or bounds[3] > h - s
    ):
        raise ValueError(
            "Rendered glyphs exceed label safe margins; select another font or label size"
        )
    return im


def raster_row(row, g, strict=False):
    if strict and g.errors():
        raise ValueError("; ".join(g.errors()))
    extent = max(
        g.backing, g.left + 3 * g.width + 2 * g.gap_x + g.right + max(0, g.offset_x)
    )
    # Invalid geometry is shown at its stated extent, never silently compressed.
    im = Image.new("1", (g.dots(extent), g.dots(g.height)), 1)
    for col, p in enumerate(row):
        if p:
            tile = label(p, g)
            x = g.dots(g.left + col * (g.width + g.gap_x) + g.offset_x)
            y = g.dots(g.top)
            if y + tile.height > im.height:
                # The white bottom margin may be cropped, never printed content.
                if (
                    tile.crop((0, im.height - y, tile.width, tile.height)).getextrema()[
                        0
                    ]
                    == 0
                ):
                    raise ValueError("Vertical offset clips label content")
            if strict:
                bounds = ImageChops.invert(tile.convert("L")).getbbox()
                if bounds and (
                    x + bounds[0] < g.dots(g.origin)
                    or x + bounds[2] > g.dots(g.origin + g.printable)
                    or y + bounds[3] > im.height
                ):
                    raise ValueError("Raster content exceeds printable dot boundaries")
            im.paste(tile, (x, y))
    return im


def tspl(queue):
    g = queue.geometry
    if g.errors():
        raise ValueError("; ".join(g.errors()))
    output = f"SIZE {g.backing:g} mm,{g.height:g} mm\r\nGAP {g.gap_y:g} mm,0 mm\r\nDIRECTION 1\r\nREFERENCE 0,0\r\nSPEED {g.speed}\r\nDENSITY {g.density}\r\n".encode(
        "ascii"
    )
    for row in rows(queue.products):
        im = raster_row(row, g, True)
        # Convert backing coordinates to printer-origin coordinates, retaining only
        # the validated printable content. Bit 1 is black in TSPL BITMAP.
        cropped = Image.new("1", ((g.dots(g.printable) // 8) * 8, im.height), 1)
        bounds = ImageChops.invert(im.convert("L")).getbbox()
        if bounds and bounds[2] - g.dots(g.origin) > cropped.width:
            raise ValueError(
                "Content exceeds byte-aligned TSPL printable width; increase safe margin"
            )
        cropped.paste(im, (-g.dots(g.origin), 0))
        padded = Image.new("1", (((cropped.width + 7) // 8) * 8, cropped.height), 1)
        padded.paste(cropped, (0, 0))
        data = bytes(b ^ 255 for b in padded.tobytes())
        output += (
            f"CLS\r\nBITMAP 0,0,{padded.width // 8},{padded.height},0,".encode()
            + data
            + b"\r\nPRINT 1,1\r\n"
        )
    return output
